# ToDo-List-2

# Functionality that the app should have -

> Adding To-Do

> Deleting To-Do

> Check Task

> Total Items Count

# Some extra functionality -

> Sorting the To Dos on the basis of their name 
and time they are added

> Notification Panel

# Fetching Demo To Dos from a dummy server -

https://jsonplaceholder.typicode.com/todos
